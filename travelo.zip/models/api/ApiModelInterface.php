<?php
/**
 * Created by PhpStorm.
 * User: dzozulya
 * Date: 06.03.17
 * Time: 18:19
 */

namespace app\models\api;


interface ApiModelInterface
{
    public function response();
}