/*
 * Title:   Travelo - Travel, Tour Booking HTML5 Template - IE8 Javascript
 * Author:  http://themeforest.net/user/soaptheme
 */