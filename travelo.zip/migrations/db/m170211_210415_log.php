<?php
require(Yii::getAlias('@yii/log/migrations/m141106_185632_log_init.php'));


class m170211_210415_log extends m141106_185632_log_init
{

}
