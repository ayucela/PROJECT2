<?php
/**
 * Created by PhpStorm.
 * User: dzozulya
 * Date: 07.03.17
 * Time: 18:13
 */
?>

<article class="box">
    <figure class="col-sm-5 col-md-4">
        <a title="" href="ajax/slideshow-popup.html" class="hover-effect popup-gallery"><img width="270" height="160" alt="" src="<?=$model->getView()?>"></a>
    </figure>
    <div class="details col-sm-7 col-md-8">
        <div>
            <div>
                <h4 class="box-title"><?=$model->name?><small><i class="soap-icon-departure yellow-color"></i> <?=$model->country?>,<?=' '.$model->city?></small></h4>
                <div class="amenities">
                    <i class="soap-icon-wifi circle"></i>
                    <i class="soap-icon-fitnessfacility circle"></i>
                    <i class="soap-icon-fork circle"></i>
                    <i class="soap-icon-television circle"></i>
                </div>
            </div>
            <div>
                <div class="five-stars-container">
                    <span class="five-stars" style="width: 80%;"></span>
                </div>
                <span class="review">270 reviews</span>
            </div>
        </div>
        <div>
            <p><?= $model->description?></p>
            <div>
                <span class="price"><small>AVG/NIGHT</small>$620</span>
                <a class="button btn-small full-width text-center" title="" href="hotel-detailed.html">SELECT</a>
            </div>
        </div>
    </div>
</article>
