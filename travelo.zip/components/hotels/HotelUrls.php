<?php
/**
 * Created by PhpStorm.
 * User: dzozulya
 * Date: 04.03.17
 * Time: 7:52
 */

namespace app\components\hotels;


class HotelUrls
{
    const AVAILABILITY_URL = '/hotel-api/1.0/hotels/';
    const HOTELS_URL = '/hotel-content-api/1.0/hotels/';

}