<?php
/**
 * Created by PhpStorm.
 * User: dzozulya
 * Date: 06.03.17
 * Time: 6:59
 */

namespace app\components\hotels\queries\availability;


interface AvailabilityOptionsInterface
{


}