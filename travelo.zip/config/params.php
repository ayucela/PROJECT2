<?php

return [

    'shouldBeActivated' => false,
    'availableLocales'=>[
        'en-US'=>'English (US)',
        'ru-RU'=>'Русский (РФ)',
        'uk-UA'=>'Українська (Україна)',
    ],
    'shortLocales'=>[
        'en-US'=>'EN',
        'ru-RU'=>'RU',
        'uk-UA'=>'UK',
    ],

];
